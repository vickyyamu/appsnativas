export interface Producto{
    imagen: string
    nombre: string
    descripcion: string
    precio: number
}