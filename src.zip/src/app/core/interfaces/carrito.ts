import { Producto } from "./producto";
export interface ProductoCarrito{
    cantidad: number,
    producto: Producto
}